-- Each named section is an independently runnable SQLite SELECT statement.
-- Source-series labels and historical hourly observations are preserved.

-- query: coverage
SELECT series_id, unit_name, COUNT(*) AS expected_rows,
       COUNT(power_mw) AS measured_rows,
       SUM(power_mw IS NULL) AS missing_rows,
       SUM(power_mw = 0) AS zero_hours,
       SUM(power_mw > 0) AS positive_hours,
       SUM(power_mw < 0) AS negative_hours,
       MIN(timestamp_local) AS first_hour,
       MAX(timestamp_local) AS last_hour
FROM generation
GROUP BY series_id, unit_name
ORDER BY series_id;

-- query: summary
WITH monthly AS (
    SELECT series_id, unit_name, COUNT(power_mw) AS measured_hours,
           SUM(energy_mwh) AS energy_mwh,
           AVG(power_mw) AS mean_power_mw,
           MAX(power_mw) AS peak_power_mw,
           SUM(power_mw > 0) AS positive_hours,
           SUM(power_mw = 0) AS zero_hours
    FROM generation
    GROUP BY series_id, unit_name
)
SELECT *, ROUND(100.0 * energy_mwh / SUM(energy_mwh) OVER (), 2) AS share_selected_pct,
       ROUND(100.0 * positive_hours / measured_hours, 2) AS positive_hours_pct
FROM monthly
ORDER BY series_id;

-- query: top_readings
WITH ranked AS (
    SELECT series_id, unit_name, timestamp_local, power_mw,
           ROW_NUMBER() OVER (
               PARTITION BY series_id ORDER BY power_mw DESC, timestamp_utc
           ) AS position
    FROM generation
    WHERE power_mw IS NOT NULL
)
SELECT * FROM ranked WHERE position <= 5 ORDER BY series_id, position;

-- query: daily
SELECT series_id, SUBSTR(timestamp_local, 1, 10) AS local_day,
       COUNT(power_mw) AS measured_hours,
       SUM(energy_mwh) AS energy_mwh,
       AVG(power_mw) AS mean_power_mw,
       MAX(power_mw) AS peak_power_mw
FROM generation
GROUP BY series_id, SUBSTR(timestamp_local, 1, 10)
ORDER BY series_id, local_day;

-- query: hourly_profile
SELECT series_id, CAST(SUBSTR(timestamp_local, 12, 2) AS INTEGER) AS hour_of_day,
       COUNT(power_mw) AS observed_days,
       AVG(power_mw) AS mean_power_mw
FROM generation
GROUP BY series_id, CAST(SUBSTR(timestamp_local, 12, 2) AS INTEGER)
ORDER BY series_id, hour_of_day;

-- query: largest_changes
-- Consecutive hourly average differences, in MW. Each step spans one hour.
WITH previous AS (
    SELECT *,
           LAG(power_mw) OVER (PARTITION BY series_id ORDER BY timestamp_utc) AS previous_mw,
           LAG(timestamp_utc) OVER (PARTITION BY series_id ORDER BY timestamp_utc) AS previous_time
    FROM generation
), changes AS (
    SELECT series_id, timestamp_local, previous_mw, power_mw,
           power_mw - previous_mw AS change_mw
    FROM previous
    WHERE power_mw IS NOT NULL AND previous_mw IS NOT NULL
      AND unixepoch(timestamp_utc) - unixepoch(previous_time) = 3600
), ranked AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY series_id ORDER BY ABS(change_mw) DESC, timestamp_local
    ) AS position
    FROM changes
)
SELECT * FROM ranked WHERE position <= 5 ORDER BY series_id, position;

-- query: zero_periods
-- Contiguous reported-zero intervals, with an exclusive end timestamp.
WITH zero_rows AS (
    SELECT series_id, timestamp_utc, timestamp_local,
           unixepoch(timestamp_utc) / 3600
           - ROW_NUMBER() OVER (PARTITION BY series_id ORDER BY timestamp_utc) AS island
    FROM generation
    WHERE power_mw = 0
), runs AS (
    SELECT series_id, MIN(timestamp_local) AS start_local,
           strftime('%Y-%m-%dT%H:%M', MAX(timestamp_local), '+1 hour') AS end_local_exclusive,
           COUNT(*) AS zero_hours
    FROM zero_rows
    GROUP BY series_id, island
), ranked AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY series_id ORDER BY zero_hours DESC, start_local
    ) AS position
    FROM runs
)
SELECT * FROM ranked WHERE position <= 3 ORDER BY series_id, position;

-- query: daily_progress
WITH daily AS (
    SELECT series_id, SUBSTR(timestamp_local, 1, 10) AS local_day,
           SUM(energy_mwh) AS energy_mwh
    FROM generation
    GROUP BY series_id, SUBSTR(timestamp_local, 1, 10)
)
SELECT *,
       SUM(energy_mwh) OVER (
           PARTITION BY series_id ORDER BY local_day
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS cumulative_energy_mwh,
       AVG(energy_mwh) OVER (
           PARTITION BY series_id ORDER BY local_day
           ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ) AS trailing_mean_up_to_7_days_mwh
FROM daily
ORDER BY series_id, local_day;

-- query: hourly_readings
SELECT series_id, timestamp_local, power_mw, energy_mwh
FROM generation ORDER BY series_id, timestamp_utc;
