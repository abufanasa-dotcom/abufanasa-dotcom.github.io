"""Run the portfolio SQL and reconcile its results with the original CSV."""

import csv
import hashlib
import json
import re
import sqlite3
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_analysis():
    results_dir = ROOT / "results"
    results_dir.mkdir(exist_ok=True)
    sources = json.loads((ROOT / "sources.json").read_text(encoding="utf-8"))
    for record in sources["files"]:
        if hashlib.sha256((ROOT / record["path"]).read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError(f"Source checksum differs: {record['path']}")

    sections = re.split(r"^-- query: (\w+)\s*$", (ROOT / "analysis.sql").read_text(encoding="utf-8"), flags=re.M)
    results = {}
    with sqlite3.connect(f"file:{(ROOT / 'emsland.sqlite').as_posix()}?mode=ro", uri=True) as database:
        database.row_factory = sqlite3.Row
        for index in range(1, len(sections), 2):
            name, sql = sections[index:index + 2]
            cursor = database.execute(sql)
            rows = [dict(row) for row in cursor.fetchall()]
            results[name] = rows
            with (results_dir / f"{name}.csv").open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=[column[0] for column in cursor.description])
                writer.writeheader()
                writer.writerows(rows)

        assert database.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert not database.execute("PRAGMA foreign_key_check").fetchall()
        assert database.execute("SELECT COUNT(*) FROM generation").fetchone()[0] == 2232

    with (ROOT / "data/raw/smard_emsland_2025_01_hourly.csv").open(encoding="utf-8-sig", newline="") as handle:
        raw = list(csv.DictReader(handle, delimiter=";"))

    for monthly in results["summary"]:
        key = monthly["series_id"]
        column = next(name for name in raw[0] if f" Emsland {key} DT [MW]" in name)
        original = [Decimal(row[column].replace(".", "").replace(",", ".")) for row in raw]
        assert Decimal(str(monthly["energy_mwh"])) == sum(original)
        assert monthly["measured_hours"] == 744
        assert monthly["positive_hours"] + monthly["zero_hours"] == 744
        daily = [row for row in results["daily"] if row["series_id"] == key]
        assert len(daily) == 31 and all(row["measured_hours"] == 24 for row in daily)
        assert sum(row["energy_mwh"] for row in daily) == monthly["energy_mwh"]
        progress = [row for row in results["daily_progress"] if row["series_id"] == key]
        assert progress[-1]["cumulative_energy_mwh"] == monthly["energy_mwh"]
        for run in (row for row in results["zero_periods"] if row["series_id"] == key):
            observations = [row for row in results["hourly_readings"]
                if row["series_id"] == key and run["start_local"] <= row["timestamp_local"] < run["end_local_exclusive"]]
            assert len(observations) == run["zero_hours"]
            assert all(row["power_mw"] == 0 for row in observations)

    validation = {
        "status": "passed",
        "named_sql_queries": len(results),
        "checks": ["Saved source SHA-256 hashes", "SQLite integrity and foreign keys",
                   "2232 observations, 744 per series", "31 complete days per series",
                   "SQL energy reconciled to raw CSV with Decimal arithmetic",
                   "Daily and cumulative totals reconciled to monthly totals",
                   "Zero-period rows independently checked against observations"],
    }
    (results_dir / "analysis.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (results_dir / "validation.json").write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"validation": validation, "summary": results["summary"],
                      "largest_changes": results["largest_changes"][:2],
                      "longest_zero_periods": [row for row in results["zero_periods"] if row["position"] == 1]}, indent=2))
    return results


if __name__ == "__main__":
    run_analysis()
