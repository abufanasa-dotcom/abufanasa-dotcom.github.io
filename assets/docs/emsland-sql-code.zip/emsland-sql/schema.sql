PRAGMA foreign_keys = ON;

CREATE TABLE generation_series (
    series_id TEXT PRIMARY KEY,
    source_label TEXT NOT NULL,
    eic_code TEXT NOT NULL UNIQUE,
    operator TEXT NOT NULL,
    city TEXT NOT NULL
);

CREATE TABLE hourly_generation (
    series_id TEXT NOT NULL REFERENCES generation_series(series_id),
    timestamp_utc TEXT NOT NULL,
    timestamp_local TEXT NOT NULL,
    duration_hours REAL NOT NULL CHECK (duration_hours > 0),
    power_mw REAL,
    PRIMARY KEY (series_id, timestamp_utc)
);

CREATE VIEW generation AS
SELECT
    s.series_id,
    s.source_label AS unit_name,
    h.timestamp_utc,
    h.timestamp_local,
    h.duration_hours,
    h.power_mw,
    h.power_mw * h.duration_hours AS energy_mwh
FROM hourly_generation AS h
JOIN generation_series AS s ON s.series_id = h.series_id;
