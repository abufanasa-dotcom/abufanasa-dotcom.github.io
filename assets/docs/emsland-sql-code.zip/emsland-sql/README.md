# Emsland generation data with SQL

Independent portfolio case study of three hourly electricity generation series published by SMARD for the Emsland site in Lingen, Germany. The sample covers January 2025 and uses SQLite for the analytical queries.

## Result

All three selected series contain 744 hourly readings, for a total of 2,232 observations. The D DT series accounts for **79.48%** of the combined energy recorded across these three series.

| Published series | Energy (GWh) | Highest hourly average power (MW) | Hours with a positive value |
| --- | ---: | ---: | ---: |
| Emsland B DT | 88.166 | 490 | 329 |
| Emsland C DT | 6.879 | 118 | 76 |
| Emsland D DT | 368.211 | 912 | 537 |

`analysis.sql` contains nine queries, including joins, common table expressions, rankings, rolling aggregates and `LAG` for comparing adjacent hourly averages. Python validates the input, builds the SQLite database and renders exports. The work was developed with AI assistance.

## Reproduce

Use Python 3.12 or later. Run the following from the repository root.

```sh
python build_database.py
python analyze.py
```

The first command creates `emsland.sqlite` from the included, frozen SMARD data. The second checks source checksums, SQLite integrity and foreign keys, hourly coverage, agreement between daily and monthly totals, and agreement with independent Decimal arithmetic on the source CSV. Outputs are in `results/`. To explore the queries interactively, run `python -m sqlite3 emsland.sqlite` and open `analysis.sql`.

For the interactive German HTML report and PDF, install the listed dependencies and run the full build.

```sh
python -m pip install -r requirements.txt
python run_project.py
```

Open `REPORT.html` in a browser. The generated HTML includes its chart library for offline use.

## Method and scope

Interval energy in MWh equals average power in MW multiplied by the one-hour interval duration. The importer covers January 2025 in CET. It preserves source labels, converts blank and dash values to SQL NULL and retains reported zeroes.

The mapping of the published series to physical generating units and their January 2025 rated capacities remains unverified. The analysis reports the published series, their hourly averages and their recorded energy. Capacity factors would require matched, time-valid rated capacities. The project draws no conclusions about why a reported value is zero.

## Data

**Bundesnetzagentur | SMARD.de**, [power plant data](https://www.smard.de/home/downloadcenter/download-kraftwerksdaten), under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). `sources.json` records retrieval and checksums. Transformations include timestamp normalization, conversion from average power to interval energy, and aggregation.

## Deutsch

Unabhängige SQL-Fallstudie zu drei veröffentlichten Einspeisezeitreihen des Standorts Emsland in Lingen für Januar 2025. Alle drei Reihen enthalten jeweils 744 Stundenwerte. Die Reihe D DT liefert **79,48 % der erfassten Energie der drei ausgewählten Reihen**. Die Zuordnung zu physischen Blöcken und deren zeitgültiger Nennleistung bleibt offen. Die Befehle unter **Reproduce** erstellen Datenbank, SQL-Ergebnisse und optional den interaktiven HTML-Bericht neu.
