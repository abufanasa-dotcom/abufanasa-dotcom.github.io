"""Rebuild all results and reports from the frozen, local source files."""

from build_database import build
from analyze import run_analysis
from make_report import make_report

if __name__ == "__main__":
    build()
    run_analysis()
    make_report()
