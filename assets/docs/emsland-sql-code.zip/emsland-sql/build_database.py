"""Rebuild the January 2025 SQLite learning database from saved source files."""

import csv
import hashlib
import json
import sqlite3
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw"
SERIES = {
    "B": ("Emsland B DT", "11WD7EMSL-G-BLB0"),
    "C": ("Emsland C DT", "11WD7EMSL-G-BLCZ"),
    "D": ("Emsland D DT", "11WD7EMSL1G-GUD9"),
}
JANUARY_START = datetime(2025, 1, 1)
CET = timezone(timedelta(hours=1))


def utc_text(value):
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_power(value):
    if value.strip() in ("", "-"):
        return None
    return float(Decimal(value.replace(".", "").replace(",", ".")))


def build():
    csv_path = RAW / "smard_emsland_2025_01_hourly.csv"
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        headers = reader.fieldnames
        rows = list(reader)
    if len(rows) != 744:
        raise ValueError("Expected 744 hourly intervals for January 2025.")

    columns = {}
    for series_id, (label, _) in SERIES.items():
        matches = [name for name in headers if f" {label} [MW]" in name]
        if len(matches) != 1:
            raise ValueError(f"Missing or ambiguous column for {label}")
        columns[series_id] = matches[0]

    observations = []
    for index, row in enumerate(rows):
        start = datetime.strptime(row["Datum von"], "%d.%m.%Y %H:%M")
        end = datetime.strptime(row["Datum bis"], "%d.%m.%Y %H:%M")
        # This importer intentionally covers January, entirely within CET.
        if start != JANUARY_START + timedelta(hours=index):
            raise ValueError(f"Unexpected or duplicated interval at row {index + 2}")
        if end - start != timedelta(hours=1):
            raise ValueError(f"Non-hourly interval at row {index + 2}")
        for series_id, column in columns.items():
            observations.append((
                series_id, utc_text(start.replace(tzinfo=CET)),
                start.isoformat(timespec="minutes"), 1.0, parse_power(row[column]),
            ))

    # Confirm that the remaining columns contain only missing markers before
    # excluding them from the three-series learning table.
    omitted = [h for h in headers[2:] if h not in columns.values()]
    for column in omitted:
        if any(parse_power(row[column]) is not None for row in rows):
            raise ValueError(f"Additional observed series requires review: {column}")

    # Build in memory so validation failures leave the existing database intact.
    with sqlite3.connect(":memory:") as database:
        database.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
        database.executemany(
            "INSERT INTO generation_series VALUES (?, ?, ?, ?, ?)",
            [(key, label, eic, "RWE Generation SE", "Lingen, Niedersachsen")
             for key, (label, eic) in SERIES.items()],
        )
        database.executemany("INSERT INTO hourly_generation VALUES (?, ?, ?, ?, ?)", observations)
        database.commit()
        if database.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("SQLite integrity check failed")
        if database.execute("PRAGMA foreign_key_check").fetchall():
            raise ValueError("SQLite foreign key check failed")

        quality = {
            "period_local": "2025-01-01 00:00 through 2025-02-01 00:00 exclusive",
            "timezone": "Europe/Berlin, CET UTC+01:00 throughout this January sample",
            "source_rows": len(rows),
            "source_series_count": len(headers) - 2,
            "learning_series_count": len(SERIES),
            "learning_rows": len(observations),
            "missing_learning_values": sum(row[-1] is None for row in observations),
            "omitted_all_missing_columns": omitted,
            "source_csv_sha256": hashlib.sha256(csv_path.read_bytes()).hexdigest(),
            "series_totals": [dict(zip(["series_id", "measured_hours", "energy_mwh", "peak_mw"], row))
                for row in database.execute(
                    "SELECT series_id, COUNT(power_mw), SUM(energy_mwh), MAX(power_mw) "
                    "FROM generation GROUP BY series_id ORDER BY series_id"
                )],
            "integrity_check": "ok",
            "reporting_scope": "Source series labels retained. Physical turbine/block scope requires verification before capacity-factor calculations.",
        }
        with sqlite3.connect(ROOT / "emsland.sqlite") as output:
            database.backup(output)
        (ROOT / "data_quality.json").write_text(
            json.dumps(quality, indent=2, ensure_ascii=False) + "\n", encoding="utf-8",
        )
        print(json.dumps(quality, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    build()
