"""Create an offline interactive report, a PDF and a shareable chart from SQL results."""

import html
import json
import textwrap
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import LinearSegmentedColormap
from plotly.offline import get_plotlyjs

ROOT = Path(__file__).resolve().parent
COLORS = {"B": "#b87c24", "C": "#457ab4", "D": "#087f76"}
INK = "#153c41"


def german(value, digits=0):
    return f"{value:,.{digits}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def local_time(value):
    return datetime.fromisoformat(value).strftime("%d.%m. %H:%M")


def table_rows(rows):
    return "".join("<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>" for row in rows)


def text_block(figure, x, y, text, width=90, size=11, color=INK):
    wrapped = "\n".join(textwrap.fill(paragraph, width) for paragraph in text.split("\n"))
    figure.text(x, y, wrapped, va="top", fontsize=size, color=color, linespacing=1.5)


def make_report():
    data = json.loads((ROOT / "results/analysis.json").read_text(encoding="utf-8"))
    summary = data["summary"]
    peaks = [row for row in data["top_readings"] if row["position"] == 1]
    changes = [row for row in data["largest_changes"] if row["position"] == 1]
    zeros = [row for row in data["zero_periods"] if row["position"] == 1]
    replacements = {
        "__PLOTLY_LIBRARY__": get_plotlyjs(),
        "__RESULTS_JSON__": json.dumps(data, ensure_ascii=False).replace("</", "<\\/"),
        "__SUMMARY_ROWS__": table_rows([
            [row["unit_name"], german(row["energy_mwh"]), german(row["mean_power_mw"], 2),
             german(row["peak_power_mw"]), row["positive_hours"], row["zero_hours"]] for row in summary]),
        "__PEAK_ROWS__": table_rows([[row["series_id"], local_time(row["timestamp_local"]), german(row["power_mw"])] for row in peaks]),
        "__CHANGE_ROWS__": table_rows([[row["series_id"], local_time(row["timestamp_local"]), german(row["change_mw"])] for row in changes]),
        "__ZERO_ROWS__": table_rows([[row["series_id"], local_time(row["start_local"]), local_time(row["end_local_exclusive"]), row["zero_hours"]] for row in zeros]),
    }
    document = (ROOT / "report_template.html").read_text(encoding="utf-8")
    for marker, value in replacements.items():
        document = document.replace(marker, value)
    (ROOT / "REPORT.html").write_text(document, encoding="utf-8")

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.labelcolor": INK, "text.color": INK,
                         "xtick.color": INK, "ytick.color": INK,
                         "axes.edgecolor": "#b8c8c3", "pdf.fonttype": 42})

    figure = plt.figure(figsize=(12, 8), facecolor="#f5f6f2")
    figure.text(.07, .94, "RWE EMSLAND  /  LINGEN  /  JANUAR 2025", fontsize=11, color="#536970")
    figure.text(.07, .875, "D prägt das Stundenprofil", fontsize=27, weight="bold")
    figure.text(.07, .815, "2.232 Beobachtungen  ·  3 veröffentlichte Reihen  ·  31 vollständige Tage", fontsize=12)
    axis = figure.add_axes((.09, .48, .36, .24), facecolor="#f5f6f2")
    axis.bar([row["series_id"] for row in summary], [row["energy_mwh"] / 1000 for row in summary],
             color=[COLORS[row["series_id"]] for row in summary], width=.6)
    axis.set_ylabel("Erfasste Energie · GWh")
    axis.set_ylim(0, 440)
    for index, row in enumerate(summary):
        axis.text(index, row["energy_mwh"] / 1000 + 12, german(row["energy_mwh"] / 1000, 2), ha="center", fontsize=11)
    figure.text(.57, .67, "79,48 %", fontsize=36, weight="bold", color=COLORS["D"])
    text_block(figure, .57, .61, "Anteil der D-Reihe an der Energie der drei ausgewählten Reihen", width=37, size=12)
    text_block(figure, .57, .515, "537 von 744 Stunden mit positivem Wert in der D-Reihe", width=37, size=12)
    axis = figure.add_axes((.09, .17, .84, .23), facecolor="#f5f6f2")
    for key in COLORS:
        rows = [row for row in data["daily"] if row["series_id"] == key]
        axis.plot([datetime.fromisoformat(row["local_day"]) for row in rows],
                  [row["energy_mwh"] / 1000 for row in rows], color=COLORS[key], linewidth=2.3, label=key)
    axis.set_ylabel("Tagesenergie · GWh")
    axis.xaxis.set_major_formatter(mdates.DateFormatter("%d.%m."))
    axis.grid(axis="y", alpha=.2)
    axis.legend(ncols=3, loc="upper right", frameon=False)
    text_block(figure, .07, .095,
               "Quellenreihen B DT, C DT, D DT. Anlagenabgrenzung und Nennleistungsbezug sind offen.\nDaten: Bundesnetzagentur | SMARD.de, CC BY 4.0. SQL-Auswertung mit KI-Unterstützung.", width=112, size=9, color="#536970")
    figure.savefig(ROOT / "results/portfolio_overview.png", dpi=160, facecolor=figure.get_facecolor())

    second = plt.figure(figsize=(12, 8), facecolor="#f5f6f2")
    second.text(.07, .93, "Datenqualität und Interpretation", fontsize=25, weight="bold")
    paragraphs = [
        ("Was wurde gemessen?", "744 stündliche Originalwerte je Reihe im Januar 2025. Alle drei ausgewählten Reihen enthalten vollständige Werte. Die sieben weiteren Spalten sind im gesamten Monat leer und bleiben im Original-CSV erhalten."),
        ("Wie wird Energie berechnet?", "Energie [MWh] = mittlere Leistung [MW] × Intervalldauer [h]. Alle verwendeten Intervalle dauern eine Stunde. Die SQL-Summen wurden mit den Originaldaten unabhängig abgeglichen."),
        ("Was zeigen Nullwerte und Stundenschritte?", "Die längsten beobachteten Nullwertphasen betragen B 37 h, C 199 h und D 32 h. Die C-Phase beginnt an der Monatsgrenze. Der größte Schritt der D-Reihe beträgt -742 MW am 30. Januar um 23 Uhr CET. Ursachen benötigen ergänzende Betriebsinformationen."),
        ("Welche Zuordnung bleibt offen?", "SMARD nennt für die DT-Stammdateneinträge 359 / 359 / 340 MW. Die historischen Reihen erreichen 490 / 118 / 912 MW. RWE nennt für vollständige Blöcke andere Leistungen. Ein Kapazitätsfaktor benötigt eine bestätigte, zeitgültige Bezugsleistung. Für Wirkungsgrade wird zusätzlich Brennstoffenergie benötigt."),
        ("Wie lässt sich die Auswertung wiederholen?", "python run_project.py baut die SQLite-Datenbank auf, führt neun SQL-Auswertungen aus und erstellt die Berichte. Das Projekt enthält Quellen, Prüfsummen, Analyse-SQL, CSV-Ergebnisse, einen arabischen Lernleitfaden und Entwürfe für Lebenslauf und LinkedIn."),
    ]
    y = .84
    for title, body in paragraphs:
        second.text(.07, y, title, fontsize=13, weight="bold")
        text_block(second, .07, y - .025, body, width=117, size=10.5)
        y -= .15
    second.text(.07, .04, "Historische Daten · smard.de/home/downloadcenter/download-kraftwerksdaten  |  Anlagenkontext · rwe.com", fontsize=9, color="#536970")
    with PdfPages(ROOT / "REPORT.pdf", metadata={"Title": "Emsland im Stundenprofil", "Author": "SQL-Portfolio mit KI-Unterstützung"}) as pdf:
        pdf.savefig(figure, facecolor=figure.get_facecolor())
        pdf.savefig(second, facecolor=second.get_facecolor())
    plt.close("all")
    print("Created REPORT.html, REPORT.pdf and results/portfolio_overview.png")


if __name__ == "__main__":
    make_report()
